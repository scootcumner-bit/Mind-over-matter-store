
const products = [
  { id:1, name:'Pastel Boxing Gloves', price:40 },
  { id:2, name:'Pastel Hand Wraps', price:15 },
  { id:3, name:'Jacket with Towel Lining', price:85 }
];

const list = document.getElementById('product-list');
if(list){
  products.forEach(p=>{
    const div=document.createElement('div');
    div.className='product';
    div.innerHTML=`<h3>${p.name}</h3><p>£${p.price}</p>
    <button onclick="checkout(${p.id})">Checkout</button>`;
    list.appendChild(div);
  });
}

async function checkout(id){
  const res = await fetch('/create-checkout-session', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({productId:id})
  });
  const data = await res.json();
  window.location = data.url;
}
