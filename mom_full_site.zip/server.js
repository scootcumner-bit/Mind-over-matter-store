const express=require('express');
const app=express();
const stripe=require('stripe')(process.env.STRIPE_SECRET_KEY);

app.use(express.static('public'));
app.use(express.json());

const PRODUCTS={
  1:{name:'Pastel Boxing Gloves', amount:4000},
  2:{name:'Pastel Hand Wraps', amount:1500},
  3:{name:'Jacket with Towel Lining', amount:8500}
};

app.post('/create-checkout-session', async (req,res)=>{
  const p = PRODUCTS[req.body.productId];
  const session = await stripe.checkout.sessions.create({
    mode:'payment',
    line_items:[{
      price_data:{
        currency:'gbp',
        product_data:{name:p.name},
        unit_amount:p.amount
      },
      quantity:1
    }],
    success_url: process.env.SUCCESS_URL,
    cancel_url: process.env.CANCEL_URL
  });
  res.json({url:session.url});
});

app.listen(process.env.PORT||4242);
